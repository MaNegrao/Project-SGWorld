		<footer>
			<p>© Soft & Gaming World 2018 | All Rights Reserved</p>
			<div class="social">
				<a href="#"><img src="img/facebook.png" alt="Facebook" width="30"></a>
				<a href="#"><img src="img/twitter.png" alt="Twitter" width="30"></a>
				<a href="#"><img src="img/instagram.png" alt='Instagram' width="30"></a>
			</div>
		</footer>
		<script src="js/script.js"></script>
	</body>
</html>