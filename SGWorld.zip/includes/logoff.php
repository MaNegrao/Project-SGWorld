<?php
	session_start();
	unset($_SESSION['uemail']);
	unset($_SESSION['unome']);
	unset($_SESSION['uendereco']);
	header("Location: ../index.php");
?>