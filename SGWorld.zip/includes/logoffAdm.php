<?php
	session_start();
	unset($_SESSION['adminu']);
	unset($_SESSION['adminp']);
	header("Location: ../index.php");
?>