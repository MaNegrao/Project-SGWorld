<?php
	$user = "admin";
	$pass = md5("MNXCYY!T49J@sA");
	$passc = md5($_POST['senhaAdm']);
	
	if($_POST['admin'] != $user){
		header("Location: ../loginAdm.php?erro=1");
	}
	else{
		if($passc == $pass){
			session_start();
			$_SESSION['adminu'] = $user;
			$_SESSION['adminp'] = $passp;
			header("Location: ../adm/ListAtt.php");
		}
		else{
			header("Location: ../loginAdm.php?erro=2");
		}
	}
?>