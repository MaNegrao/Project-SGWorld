<?php
	include "../includes/headerAdm.php"
?>

<main id="cadEvento.php">
	<h2>Register your </h2>
</main>