<?php
	session_start();
	if(!isset($_SESSION['uemail'])){
		header("Location: ../signin.php?erro=3");
	}
	include "../includes/headerUser.php";
?>
<link rel="stylesheet" type="text/css" href="../css/user.css">
	<main class="pagUser">
		<h2>My Account</h2>
		<div class="content">	
			<section class="menuUser">
				<nav>
					<ul>
						<li><a href="">Inicio</a></li>
						<li><a href="">Compras</a></li>
						<li><a href="">Ingressos</a></li>
						<li><a href="">Meus Dados</a></li>
						<li><a href="">Duvidas</a></li>
					</ul>
				</nav>
			</section>
			<section class="infoUser">
				<?php
			        include "../includes/conexao.php";
			        $sql = "SELECT* from Usuario where Email = '{$_SESSION['uemail']}';";
			        $resultado = mysqli_query($conexao, $sql);
			        $dados = mysqli_fetch_array($resultado);
			    ?>
			    <h4>Name: <?=$dados['Nome']?> / <a href="#">Change</a></h4>
				<h4>E-mail: <?=$dados['Email']?></h4>
				<h4>Date of Birth: <?=$dados['dtNasc']?></h4>
				<h4>Phone: <?=$dados['Tel']?> / <a href="#">Change</a></h4>
				<h4>PassWord: ********** / <a href="#">Change</a></h4>
			</section>
		</div>
	</main>

<?php
	include "../includes/footerAdm.php";
?>