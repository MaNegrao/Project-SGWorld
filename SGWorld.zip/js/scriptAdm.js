
function confirmDelete(){
	if(!confirm("You sure you want to delete the Attraction?")){
		return false;
	}
}
